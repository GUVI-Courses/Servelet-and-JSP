package com.example.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.model.Employee;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewServlet
 */
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<a href='index.jsp'>Add New Employee</a>");
		pw.println("<h1>Employee List</h1>");
		List<Employee> empList=EmployeeDao.getAllEmployees();
		pw.print("<table border='1'>");
		pw.print("<tr><th>ID</th><th>NAME</th><th>Designation</th><th>Address</th><th>EDIT</th><th>DELETE</th>");
		for(Employee e:empList)
		{
			pw.print("<tr><td>"+e.getId()+"</td><td>"+e.getEname()+"</td><td>"+e.getDesignation()+"</td><td>"+e.getAddress()+"</td><td><a href='updateform?id="+e.getId()+"'>Edit</a></td><td><a href='delete?id="+e.getId()+"'>Delete</a>");
		}
		pw.print("</table>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
