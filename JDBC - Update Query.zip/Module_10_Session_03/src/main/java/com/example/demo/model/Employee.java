package com.example.demo.model;

public class Employee {

	private String id;
	private String ename;
	private String designation;
	private String address;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String id, String ename, String designation, String address) {
		super();
		this.id = id;
		this.ename = ename;
		this.designation = designation;
		this.address = address;
	}
	
}

