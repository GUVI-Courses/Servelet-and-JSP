package com.example.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.model.Employee;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateFormServlet
 */
public class UpdateFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateFormServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<h1>Update Employee</h1>");
		String id=request.getParameter("id");
		Employee e=EmployeeDao.getEmployeeById(id);
		pw.println("<form action='update' method='post'>");
		pw.print("<input type='hidden' name='id' value='"+e.getId()+"'/><br>");
		pw.print("NAME: <input type='text' name='ename' value='"+e.getEname()+"'/><br>");
		pw.print("DESIGNATION: <input type='text' name='designation' value='"+e.getDesignation()+"'/><br>");
		pw.print("ADDRESS: <input type='text' name='address' value='"+e.getAddress()+"'/><br>");
		pw.print("<input type='submit' value='update'/>");
		pw.print("</form>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
