package com.example.demo;

import java.util.Calendar;

import jakarta.servlet.jsp.JspWriter;
import jakarta.servlet.jsp.tagext.TagSupport;

public class DateTimeTagHandler extends TagSupport
{
	public int doStartTag()
	{
		JspWriter out=pageContext.getOut();
		try {
			out.print(Calendar.getInstance().getTime());
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return SKIP_BODY;
	}
}
